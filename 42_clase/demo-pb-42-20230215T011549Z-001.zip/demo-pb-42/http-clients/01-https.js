// 
const https = require('https');

// GET REQUESTS
// const apiKey = "pf0sQ48sewFnFeHKfV6g9VjIZ2Y6yjR1NG7BxnbC";

// const getOptions = {
//   hostname: 'api.nasa.gov',
//   port: 443,
//   path: '/planetary/apod?api_key=pf0sQ48sewFnFeHKfV6g9VjIZ2Y6yjR1NG7BxnbC',
//   method: 'GET',
//   headers: {
//     'Accept': 'application/json'
//   }
// };

// const getRequest = https.request(getOptions, (response) => {
//   console.log('Status Code => ', response.statusCode);

//   response.on('data', (rawData) => {
//     const data = JSON.parse(rawData.toString());
//     console.log(data);
//   });
// });

// getRequest.on('error', (error) => {
//   console.log(error);
// });

// getRequest.end();

// POST REQUEST

const body = JSON.stringify({
  text: 'Master Obiwan has lost a planet.'
});

const postOptions = {
  hostname: 'yodish.p.rapidapi.com',
  port: 443,
  path: '/yoda.json',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': body.length,
    'Accept': 'application/json',
    'X-RapidAPI-Key': 'c3ccad1be1msh7f469ece1e9f989p107df8jsn99d5085bc343',
    'X-RapidAPI-Host': 'yodish.p.rapidapi.com'
  }
};

const postRequest = https.request(postOptions, (response) => {
  console.log('Status Code => ', response.statusCode);

  response.on('data', (rawData) => {
    const data = JSON.parse(rawData.toString());
    console.log(data);
  });
});

postRequest.on('error', (error) => {
  console.log(error);
});

postRequest.write(body);
postRequest.end();