const { default: axios } = require('axios');

// axios.options('https://api.nasa.gov');

// const makeRequest = async () => {
//   try {
//     const response = await axios
//       .get('/planetary/apod', {
//         params: {
//           api_key: 'pf0sQ48sewFnFeHKfV6g9VjIZ2Y6yjR1NG7BxnbC' 
//         },
//         headers: {
//           'Accept': 'application/json'
//         }
//       });
//       console.log(response.status);
//       console.log(response.data);
//   }
//   catch(error) {
//     console.log(error);
//   }
// };
const body = JSON.stringify({
  text: 'Hello Everyone, How are you?'
});

const makeRequest = async () => {
  const response = await axios.post(
    body,
    {
      url: "https://"
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': body.length,
        'Accept': 'application/json',
        'X-RapidAPI-Key': 'c3ccad1be1msh7f469ece1e9f989p107df8jsn99d5085bc343',
        'X-RapidAPI-Host': 'yodish.p.rapidapi.com'
      }
    }
  );
    console.log(response.status);
    console.log(response.data);
}

makeRequest();