class APIClientTest {


  async get(url) {
    return await axios.get(url);
  }

  async post(url, body) {
    return await axios.post(url, body);
  }
}