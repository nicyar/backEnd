export const jsSchema = {
    id: String,
    nombre: String,
    email: String
}
