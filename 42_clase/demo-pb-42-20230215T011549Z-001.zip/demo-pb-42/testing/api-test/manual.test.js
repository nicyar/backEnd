const apiCient = new APIClientTest();

const products = await apiCient.get('http://localhost:8080/prtoducts');
console.log(products);