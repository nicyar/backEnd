import Todos from './index.js';
import { strict as assert } from 'assert';
import { existsSync, readFileSync, unlinkSync } from 'fs';

describe('Test de integración de tareas', () => {
  it('debería crear el contenedor de tareas vacío', () => {
    const todos = new Todos();
    assert.strictEqual(todos.list().length, 0);
  });

  it('debería adicionar tareas correctamente', () => {
    const todos = new Todos();
    todos.add('Create tests');
    assert.strictEqual(todos.list().length, 1);
    assert.deepStrictEqual(todos.list(), [
      {
        title: 'Create tests',
        complete: false
      }
    ]);

    todos.add('Teach Node js');
    assert.strictEqual(todos.list().length, 2);
    assert.deepStrictEqual(todos.list(), [
      {
        title: 'Create tests',
        complete: false
      },
      {
        title: 'Teach Node js',
        complete: false
      }
    ]);

  });

  // debería marcar una tarea como completa

  it('debería dar error cuando no hay tareas cargadas', () => {
    const todos = new Todos();

    const errorEsperado = new Error('No hay tareas');
    assert.throws(() => {
      todos.complete("tarea inexistente");
    }, errorEsperado);
  });

  // debería dar error cuando la tarea a completar no existe
  it('debería guardar una tarea en el archivo todos.txt', (done) => {
    const todos = new Todos();
    todos.add('tareas callback');
    todos.saveToFileCb((error) => {
      assert.strictEqual(existsSync('todos.txt'), true);
      const contenidoEsperado = 'tareas callback,false';
      const contenido = readFileSync('todos.txt').toString();
      assert.strictEqual(contenido, contenidoEsperado);
      done(error);
    })
  });



});

describe('comprobando funcionalidad de las promises', () => {
  let todos;
  // Before
  before(() => {
    console.log("======COMIENZO TOTAL DE LOS TESTS======");
  });

  beforeEach(() => {
    console.log("Comienzo de Test");
  });

  beforeEach(() => {
    todos = new Todos();
  }); 

  // After
  afterEach(() => {
    if (existsSync('todos.txt')) {
      unlinkSync('todos.txt');
    }
  });

  afterEach(() => {
    console.log("Fin de test");
  });

  after(() => {
    console.log("======FIN TOTAL DE LOS TESTS======");
  });

  it('debería gguardar una tarea en el archivo todos.txt (then/catch)', (done) => {
    todos.add('tareas promises TC');
    todos.saveToFilePromise()
      .then(() => {
        assert.strictEqual(existsSync('todos.txt'), true);
        const contenidoEsperado = "tareas promises TC,false";
        const conetenido = readFileSync('todos.txt').toString();
        assert.strictEqual(conetenido, contenidoEsperado);
        done();
       })
      .catch((error) => {
        done(error);
      })
  });

  it('debería gguardar una tarea en el archivo todos.txt (async/await)', async () => {
    todos.add('tareas promises AA');
    await todos.saveToFilePromise()
    assert.strictEqual(existsSync('todos.txt'), true);
    const contenidoEsperado = "tareas promises AA,false";
    const conetenido = readFileSync('todos.txt').toString();
    assert.strictEqual(conetenido, contenidoEsperado);
  });
});

it('deberia mostrar todos los productos', async () => {

})