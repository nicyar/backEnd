/**
 * 7 Conceptos fundamentales
 * 
 * 1. Modo: Production, development
 * 2. Entry: Archivo de entrada
 * 3. Target: Objetivo
 * 4. Output: Salida
 * 5. Loaders: Herramienta para empaquetar archivos diferentes de js
 * 6. Plugins: Herramientas para ejecutar adicionales a la hora de empaquetar.
 * 7. Compatibilidad: Compatibilidad con todos los navegadores.
 */

