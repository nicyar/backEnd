const mensaje1 = "Webpack";
setTimeout(() => {
  console.log(mensaje1);
}, 1000);