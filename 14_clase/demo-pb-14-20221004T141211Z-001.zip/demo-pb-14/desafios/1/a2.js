const mensaje2 = "is";
setTimeout(() => {
  console.log(mensaje2);
}, 2000);