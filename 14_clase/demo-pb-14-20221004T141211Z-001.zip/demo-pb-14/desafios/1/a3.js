const mensaje3 = "Awesome";
setTimeout(() => {
  console.log(mensaje3);
}, 3000);