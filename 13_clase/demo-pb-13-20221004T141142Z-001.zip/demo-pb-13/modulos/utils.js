// @ts-nocheck
// import moment from "moment";

let moment;
if (process.env.GIVE_TIME === 'true') {
  const { default: momentLib } = await import('moment');
  moment = momentLib;
}

export const saludarYDarHora = (nombre, giveTime) => {
  if (giveTime) {
    console.log(`Hola todos, me llamo ${nombre}, gusto en saludarlos!`);
    const time = +moment().format('h');
    const dayTime = (time > 0 && time <=12) 
      ? 'mañana'
      : (time <= 19) 
        ? 'tarde'
        : 'noche'; 
    console.log(`Son las ${moment().format('h:mm')} de la ${dayTime}`);
  }
};

// export default saludarYDarHora
