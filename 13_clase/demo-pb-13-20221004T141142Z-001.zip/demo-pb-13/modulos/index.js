// @ts-nocheck
import { saludarYDarHora as saludar } from './utils.js';

const giveTime = process.env.GIVE_TIME === 'true';
saludar('Jorge', giveTime);