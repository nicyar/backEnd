var saludo = 1234;
console.log(saludo);
