let saludo: number = 1234;

console.log(saludo);