const express = require('express');
const AWS = require('aws-sdk');

AWS.config.update({
  region: 'us-east-1' // North Virginia
});

const sns = new AWS.SNS();
const SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:105552747728:notifications';

const dynamodb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'product-inventory';

const app = express();
app.use(express.json());

async function scanDynamoRecords(scanParams) {
  try {
    let dynamoData = await dynamodb.scan(scanParams).promise();
    const items = dynamoData.Items
    while (dynamoData.LastEvaluatedKey) {
      scanParams.ExclusiveStartKey = dynamoData.LastEvaluatedKey;
      dynamoData = await dynamodb.scan(scanParams).promise();
      items.push(...dynamoData.Items);
    }
    return items;
  } catch (error) {
    throw new Error(error);
  }
}

app.get('/', (req, res) => { res.send('test api') })

app.get('/api/productos', async (req, res) => {
  const params = {
    TableName: TABLE_NAME,
  }
  try {
    const productos = await scanDynamoRecords(params);
    res.json(productos);
  } catch (error) {
    console.error('Ocurrió un error: ', error);
    res.sendStatus(500);
  }
})

app.get('/api/productos/:id', async (req, res) => {
  const params = {
    TableName: TABLE_NAME,
    Key: {
      'productId': req.params.id,
    }
  }
  try {
    const response = await dynamodb.get(params).promise();
    res.json(response.Item);
  }
  catch (error) {
    console.error('Ocurrió un error: ', error);
    res.sendStatus(500);
  }
})

app.post('/api/productos', async (req, res) => {
  const params = {
    TableName: TABLE_NAME,
    Item: req.body
  }
  try {
    await dynamodb.put(params).promise();
    console.log('se guardó')
    const prod = JSON.stringify(req.body, null, 2);
    const snsParams = {
      Message: `nuevo producto agregado!\n${prod}`,
      Subject: 'nuevo producto en demo-pb-34',
      TopicArn: SNS_TOPIC_ARN
    }
    const notificationData = await sns.publish(snsParams).promise();
    console.log('se notificó')
    console.log(notificationData);
    const responseBody = {
      Operation: 'SAVE',
      Message: 'SUCCESS',
      Item: req.body
    }
    res.json(responseBody);
  }
  catch (error) {
    console.error('Ocurrió un error: ', error);
    res.status(500).end();
  }
})

app.put('/api/productos/:id', async (req, res) => {
  const item = {
    ...req.body,
    productId: req.params.id
  }
  const params = {
    TableName: TABLE_NAME,
    Item: item
  }
  try {
    await dynamodb.put(params).promise();
    const body = {
      Operation: 'UPDATE',
      Message: 'SUCCESS',
      Item: item
    }
    res.json(body);
  }
  catch (error) {
    console.error('Ocurrió un error: ', error);
    res.sendStatus(500);
  }
})

app.delete('/api/productos/:id', async (req, res) => {
  const params = {
    TableName: TABLE_NAME,
    Key: {
      'productId': req.params.id
    },
    ReturnValues: 'ALL_OLD'
  }
  try {
    const response = await dynamodb.delete(params).promise();
    const body = {
      Operation: 'DELETE',
      Message: 'SUCCESS',
      Item: response
    }
    res.json(body);
  }
  catch (error) {
    console.error('Ocurrió un error: ', error);
    res.sendStatus(500);
  }
})

const port = process.env.PORT || 8080;
const server = app.listen(port, () => {
  console.log(`Escuchando en puerto ${server.address().port}`);
})
server.on('error', error => { console.log(error) })
