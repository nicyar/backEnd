const express = require('express');
const debug = require('debug')('myapp:products');
const router = express.Router();

const products = [
  { nombre: "Zapatos Adidas", precio: 150 },
  { nombre: "Zapatos Reebok", precio: 100 }
];

router.get('/', function(req, res, next) {
  res.render('form');
});

router.get('/all', (req, res, next) => {
  debug(JSON.stringify(products, null, 2));
  res.json(products);
});

router.post('/', function(req, res, next) {
  console.log('body', {...req.body});
  res.redirect('/products');
});

router.put('/', (req, res, next) => {
  res.send('respond with a product PUT');
});

router.delete('/', (req, res, next) => {
  res.send('respond with a product DELETE');
});

module.exports = router;
