const express = require('express');
const swaggerUi = require('swagger-ui-express');
const swaggerJsDoc = require('swagger-jsdoc');

const PORT = process.env.PORT || 8080;

const app = express();

const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Express API with Swagger",
      description: "A simple REST API made with Express and Swagger",
      version: "1.0.0"
    }
  },
  apis: [ './docs/**/*.yaml' ]
};
const specs = swaggerJsDoc(swaggerOptions);

// Routes
app.use("/docs", swaggerUi.serve, swaggerUi.setup(specs));

app.listen(PORT, () => {
  console.log("Ready on port ", PORT);
});