const fs = require('fs');



const obj = {
  foo: "bar"
};


// obj.foo = undefined;
// delete obj.foo; // NO USAR

if (obj.foo) {
  console.log("Existe");
} else {
  console.log("No existe")
}

console.log(obj);
Object.keys(obj).length


const map = new Map(); // API

map.set("foo", "bar");

console.log(map);
console.log(map.size);
console.log(map.get("foo"));

map.delete("foo");

console.log(map);

/**
 * 
 */
